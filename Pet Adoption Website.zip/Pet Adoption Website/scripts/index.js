function redirectToHomePage() {
    window.location.href = './index.html';
  }

